"use client";

import PoQuotationForm from "@/components/procurementForms/po_quotationForm";

export default function NewPrPage() {
  return (
    <div>
      <PoQuotationForm type="create" />
    </div>
  );
}
