import ComingSoonPage from '@/components/ComingSoonPage';

export default function ProductLibrary() {
  return <ComingSoonPage currentPage="Payment Gateway" />;
}
