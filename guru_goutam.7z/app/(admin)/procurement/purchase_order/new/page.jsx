
import PoForm from "@/components/procurementForms/purchase_orderForm";

export  default function NewPage(){
    return (
        <div>

            <PoForm type="create" />
        </div>
    )
}