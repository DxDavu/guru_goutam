"use client";

import SupplierForm from "@/components/procurementForms/SupplierForm";

export default function NewPrPage() {
  return (
    <div>
      <SupplierForm type="create" />
    </div>
  );
}
