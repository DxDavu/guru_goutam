// @/app/(admin)/product-library/grade/new/page.jsx

"use client";

import GradeForm from "@/components/productLibraryForms/gradeForm";

export default function NewGradePage() {
  return (
    <div className="">
      <GradeForm type="create" />
    </div>
  );
}
