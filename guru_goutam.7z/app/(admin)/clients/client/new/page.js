"use client";

import ClientForm from "@/components/clientForms/clientForm";

export default function NewClientPage() {
  return (
    <div className="">
      <ClientForm type="create" />
    </div>
  );
}