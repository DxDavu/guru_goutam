


import DeliveryChallanForm from '@/components/operationForm/delivery-challanForm'

export default function NewDeliveryChallanPage() {
    return (
      <div className="">
        <DeliveryChallanForm type="create" />
      </div>
    );
  }