import ServiceForm from "@/components/operationForm/serviceForm";

export default function NewServicePage(){
    return(
        <ServiceForm   type="create"   />
    )
}