import InvoiceForm from "@/components/operationForm/invoiceForm";



export default function invoiceNewPage() {
    return (
        <div>
            <InvoiceForm type="create" />

        </div>

    );

}