import GrnForm from "@/components/operationForm/grnForm";
export default function NewGrnPage(){
    return (
   <GrnForm   type="create" />
    );
}