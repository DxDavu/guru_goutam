'use client';
import AddLeadForm from '@/components/crmForm/leadsForm';

export default function NewPage(){
    return(
        <div>
        <AddLeadForm type="create" />
        </div>
    )
}