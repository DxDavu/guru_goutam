import React from 'react'

function page() {
  return (
    <div>page orders</div>
  )
}

export default page