// @/app/(admin)/product-library/product-template/new/page.jsx

"use client";

import ContactForm from "@/components/crmForm/ContactForm";

export default function NewProductTemplatePage() {
  return (
    <div>
      <ContactForm type="create" />
    </div>
  );
}
