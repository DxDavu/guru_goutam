'use client';
import CreateQuotationForm from '@/components/crmForm/quotationForm';

export default function NewPage(){
    return(
        <div>
        <CreateQuotationForm type="create" />
        </div>
    )
}