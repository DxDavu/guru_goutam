/** @type {import('next').NextConfig} */
export const nextConfig = {
    images: {
      domains: ["res.cloudinary.com"], // Add Cloudinary's domain here
    },
  };
  
  export default nextConfig;
  